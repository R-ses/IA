import copy 
import numpy as np
import matplotlib.pyplot as plt
import itertools
import logging, sys

logging.basicConfig(stream=sys.stderr, level=logging.DEBUG)
default_points = 100






        
#Centroid, Center of sums, Alturas, 

