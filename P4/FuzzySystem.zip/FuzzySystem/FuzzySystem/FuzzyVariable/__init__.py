from .fuzzyvariable import FuzzyVariable

