#from . import membership_function as mf
from .. import config
from .membership_function import Trimf, Gaussmf, Trapmf, Sigmoidmf, GBellmf, Logmf, Cauchymf, Tanhmf

